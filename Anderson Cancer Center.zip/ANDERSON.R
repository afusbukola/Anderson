# Install and load necessary libraries
install.packages(c("MASS", "ggplot2", "caret"))
library(MASS)
library(ggplot2)
library(caret)

# Load the breast cancer dataset
data(BreastCancer)

# Convert to data frame
df <- as.data.frame(BreastCancer)

# Standardize the data
df[, 1:30] <- scale(df[, 1:30])

# Perform PCA
pca <- prcomp(df[, 1:30], scale. = FALSE)

# Create a DataFrame with the reduced components
df_pca <- data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2], 
                     target = ifelse(df$Class == "benign", 0, 1))

# Visualize the reduced dataset
ggplot(df_pca, aes(x = PC1, y = PC2, color = factor(target))) + 
  geom_point() + 
  labs(title = "PCA Components for Anderson Cancer Center Dataset", 
       x = "Principal Component 1", 
       y = "Principal Component 2") + 
  scale_color_discrete(labels = c("Benign", "Malignant")) + 
  theme_classic()

# Split the data into training and testing sets
set.seed(42)
trainIndex <- createDataPartition(df_pca$target, p = 0.8, list = FALSE)
df_train <- df_pca[trainIndex, ]
df_test <- df_pca[-trainIndex, ]

# Implement Logistic Regression for prediction
logreg <- glm(target ~ PC1 + PC2, data = df_train, family = binomial)

# Predict on the test set
y_pred <- predict(logreg, df_test, type = "response")
y_pred_class <- ifelse(y_pred > 0.5, 1, 0)

# Evaluate the model
accuracy <- sum(y_pred_class == df_test$target) / nrow(df_test)
print(paste("Accuracy of Logistic Regression:", round(accuracy, 4)))

